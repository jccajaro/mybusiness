// Select necessary elements
const menuBar = document.querySelector('#menu-bar'); // Hamburger menu icon
const navbar = document.querySelector('.navbar'); // Navigation bar
const scrollTopBtn = document.getElementById('scroll-top'); // Back to top button
const loader = document.querySelector('.loader-container'); // Page loader
const orderForm = document.querySelector('form'); // Order form

// 1. Toggle Menu for Mobile Responsiveness
if (menuBar && navbar) {
    menuBar.addEventListener('click', () => {
        navbar.classList.toggle('active'); // Assumes CSS has .active class for visibility
    });
}

// 2. Smooth Scrolling for All Anchor Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault(); // Prevent default jump
        const href = this.getAttribute('href');
        if (href !== '#') { // Avoid empty links
            const targetElement = document.querySelector(href);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth' // Smooth scrolling effect
                });
            }
        }
        // Close menu after click (for mobile responsiveness)
        if (navbar.classList.contains('active')) {
            navbar.classList.remove('active');
        }
    });
});

// 3. Back to Top Button Functionality
if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
        if (window.scrollY > 100) { // Show button after scrolling 100px
            scrollTopBtn.style.display = 'block'; // Or use a class for better styling
        } else {
            scrollTopBtn.style.display = 'none';
        }
    });
    
    scrollTopBtn.addEventListener('click', (e) => {
        e.preventDefault(); // Prevent default anchor behavior
        window.scrollTo({
            top: 0,
            behavior: 'smooth' // Smooth scroll to top
        });
    });
}

// 4. Handle Order Form Submission
if (orderForm) {
    orderForm.addEventListener('submit', (e) => {
        e.preventDefault(); // Prevent default mailto: action
        alert('Thank you for your order! We have received your details and will contact you soon via email.');
        // You can add more functionality here, like sending data to a server using Fetch API
        // Example: fetch('/api/submit-order', { method: 'POST', body: new FormData(orderForm) })
        // For now, just reset the form
        orderForm.reset();
    });
}

// 5. Hide Loader on Page Load
window.addEventListener('load', () => {
    if (loader) {
        loader.style.display = 'none'; // Hide the loader once everything is loaded
    }
});